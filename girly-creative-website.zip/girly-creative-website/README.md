# Petal Notes — Girly Creative Website

Website editorial scrapbook yang dibuat dengan React, Vite, TypeScript, Tailwind CSS, Framer Motion, dan Lucide React.

## Menjalankan project

```bash
npm install
npm run dev
```
Buka URL lokal yang ditampilkan Vite (umumnya `http://localhost:5173`).

## Production build

```bash
npm run build
npm run preview
```
Hasil build tersimpan di folder `dist/`.

## Struktur folder
- `public/assets/illustrations`: ilustrasi SVG custom bergaya hand-drawn.
- `public/assets/stickers`: sticker SVG custom.
- `public/assets/textures`: tekstur kertas lokal.
- `src/components`: navigasi dan doodle reusable.
- `src/sections`: setiap section halaman.
- `src/animations`: wrapper animasi yang accessible.
- `src/styles`: global CSS dan responsive styling.

## Aset dan lisensi
- Seluruh ilustrasi SVG (`bouquet.svg`, `cherries.svg`, `envelope.svg`) dibuat khusus untuk project ini dan bebas digunakan bersama source project.
- `paper.svg` adalah tekstur prosedural SVG custom.
- Icon UI berasal dari **Lucide React**, lisensi ISC.
- Font menggunakan Fraunces dan DM Sans dari Google Fonts (SIL Open Font License). Font dimuat melalui CSS ketika online; fallback Georgia/Arial tersedia saat offline.
- Tidak ada stock image atau aset AI generik.

## Fitur
Responsive navigation, mobile menu, scroll reveal, floating decorations, cursor sparkle, hover cards, masonry gallery, lightbox, form validation, active navigation, smooth scroll, dan `prefers-reduced-motion`.
