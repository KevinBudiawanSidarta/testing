/// <reference types="vite/client" />
declare module '*.css';
declare module 'framer-motion' { export const motion:any; export function useReducedMotion(): boolean; }
declare module 'lucide-react' { import type {ComponentType,SVGProps} from 'react'; type Icon=ComponentType<SVGProps<SVGSVGElement>&{size?:number|string}>; export const Menu:Icon; export const X:Icon; export const ArrowDownRight:Icon; export const ArrowUpRight:Icon; export const BookHeart:Icon; export const Camera:Icon; export const Palette:Icon; export const Send:Icon; }
