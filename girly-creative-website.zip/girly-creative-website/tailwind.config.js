/** @type {import('tailwindcss').Config} */
export default {content:['./index.html','./src/**/*.{js,ts,jsx,tsx}'],theme:{extend:{colors:{cream:'#FFF9F4',pink:'#F6C9D2',blush:'#FBE4E8',cherry:'#D94E68',butter:'#F7E4A5',lavender:'#DDD5F5',ink:'#403139'},fontFamily:{display:['Georgia','serif'],sans:['Arial','sans-serif']}}},plugins:[]}
